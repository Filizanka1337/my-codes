before using 
install python and 

if you have linux or mac os type in terminal 
pip3 install tk os

if windows 
pip install tk os