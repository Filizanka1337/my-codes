import tkinter as tk
import subprocess
from tkinter import ttk
import os

def start_attack():
    threats = threats_entry.get()
    url = url_entry.get()
    port = port_entry.get()

    # Pobieranie ścieżki skryptu
    script_path = os.path.dirname(os.path.abspath(__file__))

    # Tworzenie i wykonywanie komendy
    command = f'cd "{script_path}" && python function.py {threats} {url} {port}'
    subprocess.Popen(command, shell=True)

# Tworzenie okna
window = tk.Tk()
window.title("ddos")

# Ustalanie szerokości i wysokości okna
window_width = 900
window_height = 700

# Ustawienie rozmiaru okna
window.geometry(f"{window_width}x{window_height}")

# Ustawienie czarnego tła
window.configure(bg="black")

# Tworzenie stylu
style = ttk.Style()
style.configure("Custom.TLabel", foreground="dark green", background="black")

# Etykieta Hello
hello_label = ttk.Label(window, text="DDoS", font=("Arial", 90), style="Custom.TLabel")
hello_label.pack(pady=20)

# Tabela Threats
threats_frame = ttk.Frame(window, style="Custom.TLabel")
threats_frame.pack(pady=10)

threats_label = ttk.Label(threats_frame, text="Threats:", style="Custom.TLabel")
threats_label.grid(row=0, column=0, padx=5, pady=5, sticky="e")
threats_entry = ttk.Entry(threats_frame)
threats_entry.grid(row=0, column=1, padx=5, pady=5)

# Tabela URL
url_frame = ttk.Frame(window, style="Custom.TLabel")
url_frame.pack(pady=10)

url_label = ttk.Label(url_frame, text="URL:", style="Custom.TLabel")
url_label.grid(row=0, column=0, padx=5, pady=5, sticky="e")
url_entry = ttk.Entry(url_frame)
url_entry.grid(row=0, column=1, padx=5, pady=5)

# Tabela Port
port_frame = ttk.Frame(window, style="Custom.TLabel")
port_frame.pack(pady=10)

port_label = ttk.Label(port_frame, text="Port:", style="Custom.TLabel")
port_label.grid(row=0, column=0, padx=5, pady=5, sticky="e")
port_entry = ttk.Entry(port_frame)
port_entry.grid(row=0, column=1, padx=5, pady=5)

# Przycisk Start
start_button = ttk.Button(window, text="attack", command=start_attack, width=int(window_width/12)*2)
start_button.pack(pady=20)

# Uruchomienie pętli głównej okna
window.mainloop()
